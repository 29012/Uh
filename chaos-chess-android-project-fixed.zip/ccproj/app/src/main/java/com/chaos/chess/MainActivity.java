package com.chaos.chess;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebChromeClient;
import android.view.WindowManager;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
  WebView w = new WebView(this);
  w.setBackgroundColor(0xff10131b);
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  w.setWebChromeClient(new WebChromeClient());
  setContentView(w);
  w.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}